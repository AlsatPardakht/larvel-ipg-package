<?php

namespace Alsatpardakht\Payment\Models;

Use Illuminate\Database\Eloquent\Model;

class Payverify extends Model
{
    protected $guarded = [];
}
