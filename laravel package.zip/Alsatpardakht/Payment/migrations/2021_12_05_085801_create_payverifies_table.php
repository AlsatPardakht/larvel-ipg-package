<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePayverifiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payverifies', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('TraceNumber');
            $table->bigInteger('ReferenceNumber');
            $table->bigInteger('TransactionReferenceID');
            $table->bigInteger('InvoiceNumber');
            $table->bigInteger('MerchantCode');
            $table->bigInteger('TerminalCode');
            $table->bigInteger('Amount');
            $table->bigInteger('ShaparakRefNumber');
            $table->date('InvoiceDate');
            $table->date('TransactionDate');
            $table->text('TrxHashedCardNumber');
            $table->text('MaskedCardNumber');
            $table->text('TrxMaskedCardNumber');
            $table->text('HashedCardNumber');
            $table->text('Message');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payverifies');
    }
}
