<?php

namespace Alsatpardakht\Payment;

use Illuminate\Support\Facades\Http;
use Alsatpardakht\Payment\Models\Paylink;
use Alsatpardakht\Payment\Models\Payverify;

class Paymethods
{

    protected $goToUrl = 'https://www.alsatpardakht.com/API_V1/sign.php';
    protected $verifyUrl = 'https://www.alsatpardakht.com/API_V1/callback.php';
    protected $redirectUr = 'https://www.alsatpardakht.com/API_V1/Go.php?Token=';

    public function getPayUrl(array $params)
    {
        $response = json_decode($this->sendRequest($this->goToUrl,[
            'Api' => $params['Api'],
            'Amount' => $params['Amount'],
            'InvoiceNumber' => $params['InvoiceNumber'],
            'RedirectAddress' => $params['RedirectAddress'],
        ]));

        if ($response->IsSuccess == 1 && !is_null($response->Token)) {
            Paylink::create([
                    'Amount' => $params['Amount'],
                    'InvoiceNumber' => $params['InvoiceNumber'],
                    'InvoiceDate' => $response->InvoiceDate,
                    'Token' => $response->Token,
                    'Sign' => $response->Sign
            ]);
            return redirect($this->redirectUr.$response->Token);
        }
        return false;
    }

    public function verifyPay($request,$apiKey)
    {
        $response = json_decode($this->sendRequest($this->verifyUrl,[
            'Api' => $apiKey,
            'tref' => $request['tref'],
            'iN' => $request['iN'],
            'iD' => $request['iD'],
        ]),true);

        if (is_null($response) || !$response['VERIFY']['IsSuccess'] || !$response['PSP']['IsSuccess']) {
            return response()->json(['message'=>'مشکلی در انجام تایید تراکنش بوجود آمده است.'],405);
        }

        $response = array_merge($response['PSP'],$response['VERIFY']);

        if ($response['IsSuccess'] == 1) {
            unset($response['IsSuccess']);
            Payverify::updateOrCreate(['InvoiceNumber'=>$response['InvoiceNumber']],$response);
        }

        return response()->json($response,200);
    }

    public function sendRequest($url, $options = [])
    {
        return Http::asForm()->withoutVerifying()->post($url, $options);
    }

    public function getPayLinks($InvoiceNumber)
    {
        return Paylink::where('InvoiceNumber',$InvoiceNumber)->get();
    }

    public function getPayLinksWithPaginate($InvoiceNumber,$count)
    {
        return Paylink::where('InvoiceNumber',$InvoiceNumber)->paginate($count);
    }

    public function getPayVerify($InvoiceNumber)
    {
        return Payverify::where('InvoiceNumber',$InvoiceNumber)->get();
    }

    public function getPayVerifyWithPaginate($InvoiceNumber,$count)
    {
        return Payverify::where('InvoiceNumber',$InvoiceNumber)->paginate($count);
    }
}
