<?php

namespace Alsatpardakht\Payment\Models;

Use Illuminate\Database\Eloquent\Model;

class Paylink extends Model
{
    protected $guarded = [];
}
