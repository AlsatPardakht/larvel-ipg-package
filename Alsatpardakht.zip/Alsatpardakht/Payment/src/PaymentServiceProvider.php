<?php

namespace Alsatpardakht\Payment;

use Illuminate\Support\ServiceProvider;

/**
 * Laravel Likeable Package by Ali Bayat.
 */
class PaymentServiceProvider extends ServiceProvider
{
	public function boot()
	{
        // $this->loadRoutesFrom(__DIR__.'/../routes.php');
        $this->loadMigrationsFrom(__DIR__.'/../migrations');

        $this->publishes([
            __DIR__.'/../migrations/' => database_path('migrations')
        ], 'migrations');
	}

	public function register() {}
}
